package com.mervekaradas.yanginvardemo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.mervekaradas.yanginvardemo.databinding.ActivityVerifyOtpactivityBinding;

import java.util.concurrent.TimeUnit;

public class VerifyOTPActivity extends AppCompatActivity {

    ActivityVerifyOtpactivityBinding binding;
    String mobileNo;
    String verificationId;

    private FirebaseAuth mAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityVerifyOtpactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();


        Log.d("VerifyOTPActivity", "Received mobileNumber: " + getIntent().getStringExtra("mobileNumber"));

        setupOTPInputs();
        mobileNo = getIntent().getStringExtra("mobileNumber");

        try {
            if (mobileNo != null) {
                binding.textMobile.setText(String.format("+91-%s", mobileNo));
            } else {
                Toast.makeText(this, "Mobil numara alınamadı", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){
            System.out.println(e.getMessage());
        }

        verificationId = getIntent().getStringExtra("verificationId");

        binding.btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (binding.inputCode1.getText().toString().trim().isEmpty()
                        || binding.inputCode2.getText().toString().trim().isEmpty()
                        || binding.inputCode3.getText().toString().trim().isEmpty()
                        || binding.inputCode4.getText().toString().trim().isEmpty()
                        || binding.inputCode5.getText().toString().trim().isEmpty()
                        || binding.inputCode6.getText().toString().trim().isEmpty()
                ) {
                    Toast.makeText(VerifyOTPActivity.this, "Lütfen kodu giriniz", Toast.LENGTH_SHORT).show();
                    return;
                }

                String code =
                        binding.inputCode1.getText().toString() +
                        binding.inputCode2.getText().toString() +
                        binding.inputCode3.getText().toString() +
                        binding.inputCode4.getText().toString() +
                        binding.inputCode5.getText().toString() +
                        binding.inputCode6.getText().toString();

                if (verificationId != null) {
                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.btnVerify.setVisibility(View.INVISIBLE);

                    PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(verificationId, code);
                   // signInWithPhoneAuthCredential(phoneAuthCredential);

                    FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    binding.progressBar.setVisibility(View.GONE);
                                    binding.btnVerify.setVisibility(View.VISIBLE);

                                    if (task.isSuccessful()) {

                                        String email = getIntent().getStringExtra("email");
                                        String name = getIntent().getStringExtra("name");
                                        String password = getIntent().getStringExtra("password");


                                        mAuth.createUserWithEmailAndPassword(email, password)
                                                .addOnCompleteListener(VerifyOTPActivity.this, new OnCompleteListener<AuthResult>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                                        if (task.isSuccessful()) {
                                                            // Sign in success, update UI with the signed-in user's information
                                                            //Log.d(TAG, "createUserWithEmail:success");
                                                            //FirebaseUser user = mAuth.getCurrentUser();
                                                            Toast.makeText(VerifyOTPActivity.this, "Kayıt Başarılıyla Tamamlandı!", Toast.LENGTH_LONG).show();

                                                        } else {
                                                            // If sign in fails, display a message to the user.
                                                            //Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                                            String errorMessage = task.getException().getMessage();
                                                            if (errorMessage.contains("The email address is already in use")) {
                                                                Toast.makeText(VerifyOTPActivity.this, "Bu e-posta adresi zaten kullanımda.", Toast.LENGTH_LONG).show();
                                                            } else {
                                                                Toast.makeText(VerifyOTPActivity.this, "Hata Meydana Geldi! " + errorMessage, Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    }
                                                });





                                        Intent intent = new Intent(VerifyOTPActivity.this, MainActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Bu kod ile o anki aktiviteyi kaldırıyoruz
                                        startActivity(intent);
                                        finish();
                                    } else {
                                        Toast.makeText(VerifyOTPActivity.this, "Hatalı kod", Toast.LENGTH_SHORT).show();
                                    }
                                }


                            });


                }
            }
        });


        binding.txtResendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhoneAuthOptions options =
                        PhoneAuthOptions.newBuilder(mAuth)
                                .setPhoneNumber(mobileNo)
                                .setTimeout(15L, TimeUnit.SECONDS)
                                .setActivity(VerifyOTPActivity.this)
                                .setCallbacks(mCallbacks)
                                .build();
                PhoneAuthProvider.verifyPhoneNumber(options);
            }
        });

    }


    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks =
            new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override
                public void onVerificationCompleted(PhoneAuthCredential credential) {
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    Toast.makeText(VerifyOTPActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

                }
                @Override
                public void onCodeSent(String newVerificationId, PhoneAuthProvider.ForceResendingToken token) {
                    verificationId = newVerificationId; //60saniye sonra yollanacak yollamazsa ondan önce bildir 60sn geçmeli diye ya sa sayaç koy
                    Toast.makeText(VerifyOTPActivity.this, "Yeni OTP gönderildi", Toast.LENGTH_SHORT).show();

                }


            };
    private void setupOTPInputs() {

        binding.inputCode1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    binding.inputCode2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.inputCode2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    binding.inputCode3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.inputCode3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    binding.inputCode4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.inputCode4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    binding.inputCode5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        binding.inputCode5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (!s.toString().trim().isEmpty()) {
                    binding.inputCode6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }



}