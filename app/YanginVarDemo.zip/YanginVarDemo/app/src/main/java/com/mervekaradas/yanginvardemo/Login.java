package com.mervekaradas.yanginvardemo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.mervekaradas.yanginvardemo.databinding.ActivityLoginBinding;

public class Login extends AppCompatActivity {
    ActivityLoginBinding binding;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();

     /*   if (mAuth.getCurrentUser() != null) { // Kullanıcı oturum acmışsa EN SON AÇ BUNU LOGOUT KOYDUKTAN SONRA
            Intent intent = new Intent(Login.this, MainActivity.class);
            startActivity(intent);
        }*/

        binding.btnLogin.setOnClickListener(v -> {
            String email = binding.etLoginEmail.getText().toString().trim();
            String password = binding.etLoginPassword.getText().toString().trim();
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || email == null || password == null){
                Toast.makeText(this, "Lütfen eksik alanları doldurunuz! Email: " + email + " P : " + password, Toast.LENGTH_LONG).show();

            }
            else {
                login(email,password);
            }

        });

        binding.btnRegister.setOnClickListener(v -> {
            register();
        });


    }

    private void login(String email,String password)
    {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            if (!mAuth.getCurrentUser().isEmailVerified()) {
                                Toast.makeText(Login.this, "Please verify your email id!", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Intent intent = new Intent(Login.this, MainActivity.class);
                                startActivity(intent);
                            }

                        } else {
                            // If sign in fails, display a message to the user.
                            Toast.makeText(Login.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void register()
    {
        Intent intent = new Intent(Login.this, Register.class);
        startActivity(intent);
    }


}