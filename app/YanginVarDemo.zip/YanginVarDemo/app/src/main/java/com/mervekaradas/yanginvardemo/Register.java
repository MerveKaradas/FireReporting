package com.mervekaradas.yanginvardemo;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.auth.User;
import com.mervekaradas.yanginvardemo.databinding.ActivityRegisterBinding;

import java.util.HashMap;

public class Register extends AppCompatActivity {

    ActivityRegisterBinding binding;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        binding.btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register(view);
            }
        });
    }



    public void register(View view){

        String name = binding.etName.getText().toString().trim();
        String email = binding.etEmail.getText().toString().trim();
        String password = binding.etPassword.getText().toString().trim();
        String phone = binding.etPhone.getText().toString().trim();


        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(phone)){
            Toast.makeText(this, "Lütfen eksik alanları doldurunuz!", Toast.LENGTH_LONG).show();
        }
        else if (password.length() < 6) {
            Toast.makeText(this, "Şifreniz en az 6 karakter olmalıdır!", Toast.LENGTH_LONG).show();
        }
        else{
            checkEmailAndProceed(name, phone, email, password);

        }
    }

    private void checkEmailAndProceed(String name, String phone, String email, String password) {

        // Check if email is already registered
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        db.collection("users").whereEqualTo("email", email).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null && querySnapshot.isEmpty()) {
                            // Bu e-posta adresi ile henüz kayıtlı bir kullanıcı yok
                            // proceedToSmsVerification(name, phone, email, password); //BURASI AÇILACAK SMS DOĞRULAMA HATA ÇIKARIYOR ŞİMDİLİKTE
                            proceedEmailVerification(name, phone, email, password);
                        } else {
                            // Bu e-posta adresi ile zaten bir kullanıcı kayıtlı
                            Toast.makeText(this, "This email is already registered", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Error checking email", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    private void proceedToSmsVerification(String name, String phone, String email, String password) {
        Intent intent = new Intent(Register.this, SendOTPActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("phone", phone);
        intent.putExtra("email", email);
        intent.putExtra("password", password);
        startActivity(intent);
    }


    private void addUserToFirestore(String name, String phone, String email, String password) {
        HashMap<String, Object> userMap = new HashMap<>();
        userMap.put("name", name);
        userMap.put("phone", phone);
        userMap.put("email", email);
        userMap.put("password", password);

        // Add a new document with a generated ID
        db = FirebaseFirestore.getInstance();

        db.collection("users")
                .add(userMap)
                .addOnSuccessListener(documentReference -> {
                    Log.d("TAG", "DocumentSnapshot added with ID: " + documentReference.getId());

                })
                .addOnFailureListener(e -> Log.w("TAG", "Error adding document", e));
    }

    private void proceedEmailVerification(String name, String phone, String email, String password) {
        mAuth = FirebaseAuth.getInstance();

        mAuth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.d("TAG", "createUserWithEmail:success");
                          //  addUserToFirestore(email, password); FİRESTORE DA EKLENECEK

                            mAuth.getCurrentUser().sendEmailVerification()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                // Email verification sent
                                                Toast.makeText(Register.this, "User register successfully. Email verification sent. Please verify email id!", Toast.LENGTH_SHORT).show();
                                                addUserToFirestore(name, phone, email, password);
                                            } else {
                                                // Email verification failed
                                                Toast.makeText(Register.this, "Email verification failed!", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });



                        } else {
                            // If sign in fails, display a message to the user.
                            Log.w("TAG", "createUserWithEmail:failure", task.getException());
                            Toast.makeText(Register.this, "Authentication failed.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


}