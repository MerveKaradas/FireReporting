package com.mervekaradas.yanginvardemo;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.mervekaradas.yanginvardemo.databinding.ActivitySendOtpactivityBinding;

import java.util.concurrent.TimeUnit;

public class SendOTPActivity extends AppCompatActivity {

    ActivitySendOtpactivityBinding binding;
    private FirebaseAuth mAuth;
    private  String mVerificationId;
    String inputMobileNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivitySendOtpactivityBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        try {
            FirebaseApp.initializeApp(this);
            // FirebaseAuth nesnesini başlat
            mAuth = FirebaseAuth.getInstance();

            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                // Kullanıcı oturum açmış
                System.out.println(Log.d("RegisterActivity", "User is signed in: " + currentUser.getUid()));
            } else {
                // Kullanıcı oturum açmamış
                System.out.println(Log.d("RegisterActivity", "No user is signed in."));
            }
        } catch (Exception e) {
            System.out.println(Log.e("RegisterActivity", "FirebaseAuth initialization error", e));
        }


        inputMobileNo =  getIntent().getStringExtra("phone");
        binding.inputMobile.setText(inputMobileNo);
        binding.inputMobile.setEnabled(false);


        binding.btnGetOTP.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (inputMobileNo.isEmpty()) {
                    System.out.println("1");
                    binding.inputMobile.setEnabled(true);
                    Toast.makeText(SendOTPActivity.this, "Lütfen telefon numaranızı giriniz", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    Toast.makeText(SendOTPActivity.this, "OTP gönderildi", Toast.LENGTH_SHORT).show();

                    binding.progressBar.setVisibility(View.VISIBLE);
                    binding.btnGetOTP.setVisibility(View.INVISIBLE);

                    sendVerificationCode(inputMobileNo);

                }

            }
        });




    }

    private void sendVerificationCode(String phoneNumber) {
        Log.d("SendOTPActivity", "sendVerificationCode: " + phoneNumber);
        System.out.println("burdaa");
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(phoneNumber)
                        .setTimeout(15L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks =
            new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                @Override
                public void onVerificationCompleted(PhoneAuthCredential credential) {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.btnGetOTP.setVisibility(View.VISIBLE);
                }

                @Override
                public void onVerificationFailed(@NonNull FirebaseException e) {
                    System.out.println( "Exception: " + e.getMessage());
                    binding.progressBar.setVisibility(View.GONE);
                    binding.btnGetOTP.setVisibility(View.VISIBLE);
                    Toast.makeText(SendOTPActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();

                }
                @Override
                public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken token) {

                    binding.progressBar.setVisibility(View.GONE);
                    binding.btnGetOTP.setVisibility(View.VISIBLE);

                    mVerificationId =s ;

                    Intent intent = new Intent(getApplicationContext(), VerifyOTPActivity.class);
                    intent.putExtra("verificationId", mVerificationId);
                    intent.putExtra("mobileNumber", inputMobileNo);
                 //   intent.putExtra("phone", inputMobileNo);
                    intent.putExtra("email", getIntent().getStringExtra("email"));
                    intent.putExtra("password", getIntent().getStringExtra("password"));
                    intent.putExtra("name", getIntent().getStringExtra("name"));

                    startActivity(intent);
                }
            };
}